$(function(){
	
	$('#wrap .message').on('click',function(){
		location.href="admin/message";
	});
	$('#wrap .blog').on('click',function(){
		location.href="admin/blog";
	});

});