<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <base href="<?php echo site_url(); ?>">
    <link rel="stylesheet" href="css/admin_common.css">
</head>
<body>
    <div id="wrap">
        <h3 class="title">管理员管理系统</h3>
       	<ul class="tab">
       		<li class="message">留言管理</li>
       		<li class="blog">博客管理</li>
       	</ul>
       	<div class="box">
       		<div class="one show"  ></div>
       		<div class="two"></div>
       	</div>
       	
    </div>
    <script src="js/jquery.js"></script>
    <script src="js/admin_mrg.js"></script>
</body>
</html>